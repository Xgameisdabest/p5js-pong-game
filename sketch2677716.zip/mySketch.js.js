let X;
let Y;
let XSPD = 10;	
let YSPD = 10;				  
let Radius = 15;				
let RectLength = 150;
let BKG = "#white"; //BACKGROUND COLOR
let score = 0;

let ModeSel = 0;

let Paused = false;

let ShowHelp = true;

let BallBasket = [];		//THE GAME STARTS WITH A SINGLE BALL IN THIS MODE
let BallAOA = 0;
let G = 0;
let Minimum = 0;					//THE MINIMUM NUMBER OF BALLS FOR THE HARSH MODE
let RealMinimum = 1;

let RX1;
let RX2;
let PSPD = 25;
let score_1 = 0;
let score_2 = 0;

let CompWinner = null;
let CompCooldownStart = 0;
let CompResetting = false;
let lastLoser = "blue"; // or "red" – just a placeholder to start

function getRandomPosition(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateObstacleList() {
  return [
    [getRandomPosition(-300, 300), getRandomPosition(-300, 300), "green", 0],
    [getRandomPosition(-300, 300), getRandomPosition(-300, 300), "red", 0],
    [getRandomPosition(-300, 300), getRandomPosition(-300, 300), "blue", 0],
    [getRandomPosition(-300, 300), getRandomPosition(-300, 300), "white", 0],
    [getRandomPosition(-300, 300), getRandomPosition(-300, 300), "black", 0]
  ];
}

let ObstacleList = generateObstacleList();

let Log1 = [0, 0];
let Log2 = [0, 0];
let Toggler = false;
let XY = 0;	

function setup(){
	createCanvas(windowWidth, windowHeight)
	background(BKG)
	X = windowWidth / 2
	Y = windowHeight / 2
	textSize(100);
  fill(255);
  stroke(0);
  strokeWeight(4)
	BallBasket.push([X, Y, XSPD, YSPD])
	RX1 = windowWidth / 2
	RX2 = windowWidth / 2
	textFont("Trebuchet MS")
}

/*
The following function resets the ball's location - X and Y are directly used for the ball.
Thus, without this function, the ball stays at the last position after the game is quitted when it is reopened.
However, the latest velocity vector will be preserved.
*/

function HelperScreen(mode) {
	background(BKG);
	textAlign(CENTER);
	fill("black");
	textSize(40);
	text("HOW TO PLAY", windowWidth / 2, windowHeight / 2 - 100);
	textSize(24);
	fill("cyan");

	if (mode === 1) {
	fill("red")
	text("Red: Use A/D to move", width / 2, height / 2 - 40);
	fill("cyan")
	text("Blue: Use Left/Right Arrow keys", width / 2, height / 2);
	fill("yellow")
	text("Press Q to pause the game", width / 2, height / 2 + 60);
} else {
	text("Move your mouse left and right to control the platform!", width / 2, height / 2);
	text("Press Q to pause the game", width / 2, height / 2 + 40);
}


	fill("grey");
	rect(windowWidth / 2 - 100, windowHeight / 2 + 100, 200, 50, 10);
	fill("green");
	textSize(20);
	text("Start", windowWidth / 2, windowHeight / 2 + 130);

	if (mouseIsPressed &&
		mouseX >= windowWidth / 2 - 100 &&
		mouseX <= windowWidth / 2 + 100 &&
		mouseY >= windowHeight / 2 + 100 &&
		mouseY <= windowHeight / 2 + 150) {
		ShowHelp = false;
	}
	textAlign(CENTER);
}


function RESET(){
	X = windowWidth / 2
	Y = windowHeight / 2
	RectLength = 150;
	BallBasket = [[X, Y, XSPD, YSPD, 1]]
	Minimum = 0;
	score = 0;
	RX1 = windowWidth / 2;
	RX2 = windowWidth / 2;
}

/*
UI Structure:
	 + The start screen:
	 | 		Basically buttons.
	 | 
	 + The result screen:
	 |		Scores, game statistics and all.
	 |
	 + The statistics:
	 | 		Statistics and settings.
	 |
	 + Basically that's it for now.
*/

function MODESET(MODE){
	ModeSel = MODE
}

function StartSCR(){
	background("white")
	textSize(100)
	fill("cyan")
	textAlign("center")
	text("Ping Pong Ultra", windowWidth / 2, windowHeight / 2 - 150)
	textSize(50)
	text("aka Pong Pong", windowWidth / 2, windowHeight / 2 - 75)
	
	//SELECTIONS
	let ButtonLength = 500
	let ButtonWidth = 50
	let ButtonRadius = 10
	let ButtonGap = 10
	fill("grey")
	//rect(x, y, width, height, [radius])
	let K1 = rect(windowWidth / 2 - ButtonLength / 2, windowHeight / 2 - ButtonWidth / 2, ButtonLength, ButtonWidth, ButtonRadius)
	let K2 = rect(windowWidth / 2 - ButtonLength / 2, windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 1, ButtonLength, ButtonWidth, ButtonRadius)
	let K3 = rect(windowWidth / 2 - ButtonLength / 2, windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 2, ButtonLength, ButtonWidth, ButtonRadius)
	let K4 = rect(windowWidth / 2 - ButtonLength / 2, windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 3, ButtonLength, ButtonWidth, ButtonRadius)
	let K5 = rect(windowWidth / 2 - ButtonLength / 2, windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 4, ButtonLength, ButtonWidth, ButtonRadius)
	
	textSize(25)
	fill("green")
	textAlign("center")
	text("Competition", windowWidth / 2, windowHeight / 2 + ButtonWidth / 4 - 2.5)
	
	textSize(25)
	fill("cyan")
	textAlign("center")
	text("Single Player", windowWidth / 2, windowHeight / 2 + ButtonWidth / 4 - 2.5 + (ButtonWidth + ButtonGap) * 1)
	
	textSize(25)
	fill("blue")
	textAlign("center")
	text("Obstacles", windowWidth / 2, windowHeight / 2 + ButtonWidth / 4 - 2.5 + (ButtonWidth + ButtonGap) * 2)
	
	textSize(25)
	fill("red")
	textAlign("center")
	text("Miniaturized", windowWidth / 2, windowHeight / 2 + ButtonWidth / 4 - 2.5 + (ButtonWidth + ButtonGap) * 3)

	textSize(25)
	fill("purple")
	textAlign("center")
	text("Exponentiale", windowWidth / 2, windowHeight / 2 + ButtonWidth / 4 - 2.5 + (ButtonWidth + ButtonGap) * 4)

	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - ButtonLength / 2 & 
			mouseX <= windowWidth / 2 - ButtonLength / 2 + ButtonLength & 
			mouseY >= windowHeight / 2 - ButtonWidth / 2 & 
			mouseY <= windowHeight / 2 - ButtonWidth / 2 + ButtonWidth
		 ){
		RESET()
		setTimeout(MODESET(1), 250)
	}
	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - ButtonLength / 2 & 
			mouseX <= windowWidth / 2 - ButtonLength / 2 + ButtonLength & 
			mouseY >= windowHeight / 2 - ButtonWidth / 2 + ButtonWidth * 1 & 
			mouseY <= windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 2
		 ){
		RESET()
		setTimeout(MODESET(2), 250)
	}
if (mouseIsPressed & 
    mouseX >= windowWidth / 2 - ButtonLength / 2 & 
    mouseX <= windowWidth / 2 - ButtonLength / 2 + ButtonLength & 
    mouseY >= windowHeight / 2 - ButtonWidth / 2 + ButtonWidth * 2 & 
    mouseY <= windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 3
    ){
  RESET()
  ObstacleList = generateObstacleList(); // <-- add this!
  setTimeout(() => MODESET(3), 250)
}
	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - ButtonLength / 2 & 
			mouseX <= windowWidth / 2 - ButtonLength / 2 + ButtonLength & 
			mouseY >= windowHeight / 2 - ButtonWidth / 2 + ButtonWidth * 3 & 
			mouseY <= windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 4
		 ){
		RESET()
		setTimeout(MODESET(4), 250)
	}
	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - ButtonLength / 2 & 
			mouseX <= windowWidth / 2 - ButtonLength / 2 + ButtonLength & 
			mouseY >= windowHeight / 2 - ButtonWidth / 2 + ButtonWidth * 4 & 
			mouseY <= windowHeight / 2 - ButtonWidth / 2 + (ButtonWidth + ButtonGap) * 5
		 ){
		RESET()
		setTimeout(MODESET(5), 250)
	}
}

//==================================================COMPETING MODE - 2 PLAYERS ONE SCREEN==================================================//

function Competition() {
	background(BKG);

	// PAUSE BUTTON
	fill("deepskyblue");
	rect(windowWidth - 200, 50, 100, 50);
	textAlign("center");
	textSize(25);
	text("PAUSE", windowWidth - 150, 75 + 25 / 4 + 5);
	if (mouseIsPressed &&
		mouseX >= windowWidth - 200 &&
		mouseX <= windowWidth - 100 &&
		mouseY >= 50 &&
		mouseY <= 100) {
		Paused = true;
		return;
	}

	// PLAYER PADDLES
	fill("red");
	rect(RX1 - RectLength / 2, 25, RectLength, 25);
	fill("blue");
	rect(RX2 - RectLength / 2, windowHeight - 50, RectLength, 25);

	// PLAYER MOVEMENT
	if (keyIsDown(65) && RX1 >= RectLength / 2) {
		RX1 -= PSPD;
	} else if (keyIsDown(68) && RX1 <= windowWidth - RectLength / 2) {
		RX1 += PSPD;
	}
	if (keyIsDown(RIGHT_ARROW) && RX2 <= windowWidth - RectLength / 2) {
		RX2 += PSPD;
	} else if (keyIsDown(LEFT_ARROW) && RX2 >= RectLength / 2) {
		RX2 -= PSPD;
	}

	// SHOW SCORES
	fill("red");
	text(score_1, 120, 120);
	fill("blue");
	text(score_2, 120, windowHeight - 120);

	// Ball fall delay logic
	if (CompResetting) {
		let elapsed = millis() - CompCooldownStart;

		fill("black");
		textSize(40);
		textAlign(CENTER);
		text(`${CompWinner.toUpperCase()} Player Wins!`, width / 2, height / 2 - 30);
		textSize(25);
		text("Next round starts in " + ceil(3 - elapsed / 1000), width / 2, height / 2 + 30);

		if (elapsed >= 3000) {
			CompResetting = false;
			CompWinner = null;

			// Launch ball downward toward the losing player
			// Reset ball to center with slight tilt
			X = width / 2;
			Y = height / 2;

			// Slight angle: ~15 to 30 degrees
			let angle = radians(random(15, 30));
			let direction = (lastLoser === "red" ? 1 : -1); // 1 = down (red), -1 = up (blue)

			// Random left or right tilt
			let xdir = random([-1, 1]);

			XSPD = xdir * cos(angle) * 10;
			YSPD = direction * sin(angle) * 10;

			// Reset paddles to center
			RX1 = width / 2;
			RX2 = width / 2;

		}
		return;
	}

	// BALL
	fill("grey");
	circle(X, Y, 2 * Radius);
	X += XSPD;
	Y += YSPD;

	// Ball out of bounds - scoring
	if (Y >= windowHeight - Radius) {
		score_1 += 1;
		CompWinner = "red";
		lastLoser = "blue";
		CompResetting = true;
		CompCooldownStart = millis();
		return;
	}
	if (Y <= Radius) {
		score_2 += 1;
		CompWinner = "blue";
		lastLoser = "red";
		CompResetting = true;
		CompCooldownStart = millis();
		return;
	}

	// Wall bounce
	if (X <= Radius || X >= windowWidth - Radius) {
		XSPD = -XSPD;
	}

	// Paddle bounce
	if (Y - Radius <= 50 &&
		X >= RX1 - RectLength / 2 &&
		X <= RX1 + RectLength / 2 &&
		YSPD < 0) {
		YSPD = -YSPD;
	}
	if (Y + Radius >= windowHeight - 50 &&
		X >= RX2 - RectLength / 2 &&
		X <= RX2 + RectLength / 2 &&
		YSPD > 0) {
		YSPD = -YSPD;
	}
}

//==================================================SINGLEPLAYER==================================================//

function SinglePlayer(){
	background(BKG)
	fill("deepskyblue")
	rect(100, 50, 100, 50);
	textAlign("center")
	textSize(25)
	text("PAUSE", 150, 75 + 25 / 4 + 5);
	if (mouseIsPressed & 
			mouseX >= windowWidth - 200 & 
			mouseX <= windowWidth - 100 & 
			mouseY >= 50 & 
			mouseY <= 50 + 50
		 ){
		Paused = true;
	}
	fill("grey")
	circle(X, Y, 2 * Radius)
	rect(mouseX - RectLength / 2, windowHeight - 50, RectLength, 25)
	X += XSPD
	Y += YSPD
	
	if (Y <= Radius){
		YSPD = -YSPD
	}
	
	if (Y >= windowHeight - Radius){
		ModeSel = -1
	}
	
	if (X <= Radius | X >= windowWidth - Radius){
		XSPD = -XSPD
	}
	
	if (Y + Radius >= windowHeight - 50 &
			X >= mouseX - RectLength / 2 &
			X <= mouseX + RectLength / 2 & 
		 	YSPD > 0
		 ){
		YSPD = -YSPD
		score += 1
	}
	text(score, windowWidth - 120, 120)
}

//==================================================MINIATURE==================================================//

function Miniaturized(){
	background(BKG)
	fill("deepskyblue")
	rect(100, 50, 100, 50);
	textAlign("center")
	textSize(25)
	text("PAUSE", 150, 75 + 25 / 4 + 5);
	if (mouseIsPressed & 
			mouseX >= windowWidth - 200 & 
			mouseX <= windowWidth - 100 & 
			mouseY >= 50 & 
			mouseY <= 50 + 50
		 ){
		Paused = true;
	}
	fill("grey")
	circle(X, Y, 2 * Radius)
	rect(mouseX - RectLength / 2, windowHeight - 50, RectLength, 25)
	X += XSPD
	Y += YSPD
	
	if (Y <= Radius){
		YSPD = -YSPD
	}
	
	if (Y >= windowHeight - Radius){
		ModeSel = -1
	}
	
	if (X <= Radius | X >= windowWidth - Radius){
		XSPD = -XSPD
	}
	
	if (Y + Radius >= windowHeight - 50 &
			X >= mouseX - RectLength / 2 &
			X <= mouseX + RectLength / 2 & 
		 	YSPD > 0
		 ){
		YSPD = -YSPD
		RectLength -= 10
		score += 1
	}
	
	if (RectLength <= 30){
		RectLength = 30
	}
	text(score, windowWidth - 120, 120)
}

//==================================================OBSTACLES==================================================//

function Obstacles(){
	background(BKG);
	fill("deepskyblue");
	rect(100, 50, 100, 50);
	textAlign(CENTER);
	textSize(25);
	text("PAUSE", 150, 75 + 25 / 4 + 5);

	if (mouseIsPressed &&
		mouseX >= 100 &&
		mouseX <= 200 &&
		mouseY >= 50 &&
		mouseY <= 100) {
		Paused = true;
		return;
	}

	// Draw player paddle
	fill("grey");
	rect(mouseX - RectLength / 2, windowHeight - 50, RectLength, 25);

	// Move ball
	X += XSPD;
	Y += YSPD;

	// Draw ball
	fill("grey");
	circle(X, Y, 2 * Radius);

	// Draw obstacles
	for (let r = 0; r < ObstacleList.length; r++) {
		let ox = windowWidth / 2 - ObstacleList[r][0];
		let oy = windowHeight / 2 - ObstacleList[r][1];
		let ow = 100;
		let oh = 50;
		let color = ObstacleList[r][2];

		fill(color);
		rect(ox, oy, ow, oh);

		// Check collision with ball (Axis-Aligned Bounding Box)
		if (X + Radius > ox && X - Radius < ox + ow &&
			Y + Radius > oy && Y - Radius < oy + oh) {

			// Determine which side to bounce
			let prevX = X - XSPD;
			let prevY = Y - YSPD;

			let fromLeft = prevX <= ox;
			let fromRight = prevX >= ox + ow;
			let fromTop = prevY <= oy;
			let fromBottom = prevY >= oy + oh;

			if ((fromLeft && XSPD > 0) || (fromRight && XSPD < 0)) {
				XSPD = -XSPD;
			}
			if ((fromTop && YSPD > 0) || (fromBottom && YSPD < 0)) {
				YSPD = -YSPD;
			}
		}
	}

	// Collision with screen boundaries
	if (Y <= Radius) {
		YSPD = -YSPD;
	}

	if (Y >= windowHeight - Radius) {
		ModeSel = -1; // Game over
		return;
	}

	if (X <= Radius | X >= windowWidth - Radius) {
		XSPD = -XSPD;
	}

	// Paddle bounce
if (Y + Radius >= windowHeight - 50 &&
	X >= mouseX - RectLength / 2 &&
	X <= mouseX + RectLength / 2 &&
	YSPD > 0) {
	YSPD = -YSPD;
	score += 1;

	// Randomize obstacle positions
	for (let i = 0; i < ObstacleList.length; i++) {
		let randX = random(-windowWidth / 2 + 100, windowWidth / 2 - 100);
		let randY = random(-windowHeight / 2 + 100, windowHeight / 2 - 100);
		ObstacleList[i][0] = randX;
		ObstacleList[i][1] = randY;
		}
	}
	text(score, windowWidth - 120, 120)
}

//==================================================BACTERIA MODE==================================================//

function Exponentiale() {
	background(BKG)
	fill("deepskyblue")
	rect(100, 50, 100, 50);
	fill(0)
	textAlign("center")
	textSize(25)
	text("PAUSE", 150, 75 + 25 / 4 + 5);
	if (mouseIsPressed & 
			mouseX >= windowWidth - 200 & 
			mouseX <= windowWidth - 100 & 
			mouseY >= 50 & 
			mouseY <= 50 + 50
		 ){
		Paused = true;
	}
	fill("grey")
	rect(mouseX - RectLength / 2, windowHeight - 50, RectLength, 25)
	let z;
	// `z++` means incrementing after every iteration.
	/*
	Here we are making each ball in the 'basket' move.
	*/
	for (z = 0; z < BallBasket.length; z++){
		BallBasket[z][0] += BallBasket[z][2]
		BallBasket[z][1] += BallBasket[z][3]
		circle(BallBasket[z][0], BallBasket[z][1], 2 * Radius)
	}
	//CHECKING COLLISION
	for (z = 0; z < BallBasket.length; z++){
		//First we dump the balls out of bounds out of bounds.
		if (BallBasket[z][1] >= windowHeight
			 ){
			BallBasket[z] = [windowWidth + 100, windowHeight + 100, 0, 0, 0]
			RealMinimum -= 1;
			//JUST TREATING THE ONE-BALL SITUATION AS A SPECIAL CASE
			if (BallBasket.length == 1){
				ModeSel = -1
			}
			continue;
		}
		//Collision with the left and right wall.
		if (BallBasket[z][0] < Radius | BallBasket[z][0] + Radius >= windowWidth){
			BallBasket[z][2] = -BallBasket[z][2]
		}
		//Collision with the top wall.
		if (BallBasket[z][1] <= Radius &
				BallBasket[z][3] < 0
			 ){
			BallBasket[z][3] = -BallBasket[z][3]
		}
	let g;
	
	//HERE'S MULTIPLICATION UPON COLLISION WITH PADDLE
	for (g = 0; g < BallBasket.length; g++){
		/*
		We'll check collision with the top edge like normal.
		*/
		if (BallBasket[z][1] + Radius >= windowHeight - 50 &
				BallBasket[z][0] >= mouseX - RectLength / 2 &
				BallBasket[z][0] <= mouseX + RectLength / 2 & 
				BallBasket[z][3] > 0
			 ){
				BallBasket[z][3] = -BallBasket[z][3]
				//WE WILL NEED THE BALL'S ANGLE OF ATTACK.
				if (BallBasket[z][2] != 0){
					BallAOA = atan(BallBasket[z][3] / BallBasket[z][2]) //THIS APPROACH ONLY WORKS IF ALL THE OPERATION INVOLVED GIVES A DEFINED OUTPUT.
				}
				else {
					BallAOA = 90;
				}
				if (BallAOA <= 10){
					BallAOA += 45
				}
				/*
				For now, this angle calculation is enough as the ball never exceeds 90 degrees azimuth - given North is up.
				*/
				G += 1 //INCREMENT THE TRISTATE VARIABLE BY 1 TO START MULTIPLYING.
			}
		else {
			continue; //NOT REALL THAT IMPORTANT, JUST TO MAKE SURE IT JUMPS BEFORE THE MULTIPLICATION PART.
		}
		//THIS ENSURES THE BALL ONLY MULTIPLIES ONCE, AND ONCE ONLY UPON COLLISION WITH THE PADDLE.
		if (G == 1){
			BallBasket.push([BallBasket[z][0], BallBasket[z][1], -sin(BallAOA / 2) * XSPD, cos(BallAOA / 2) * YSPD])
			BallBasket.push([BallBasket[z][0], BallBasket[z][1], -sin(BallAOA * 1.5) * XSPD, cos(BallAOA * 1.5) * YSPD])
			Minimum = BallBasket.length
			score += 1
			G += 1
			}
		}
		let x
		for (x = 0; x < BallBasket.length; x++){
			RealMinimum += 1
		}
		if (RealMinimum + 1 < Minimum){
			ModeSel = -1
		}
		RealMinimum = 0
	}
	//RESET THE MULTIPLICATION TRISTATE CONTROLLER
	G = 0;
	text(score, windowWidth - 120, 120)
}

function StopPause(){
	Paused = false;
}
function Return(){
	ModeSel = 0;
	Paused = false;
	ShowHelp = true;
}

function Pause(){
	background(BKG)
	fill("grey")
	rect(windowWidth / 2 - 100, windowHeight / 2 - 25, 200, 50, 10)
	fill("red")
	textFont("Courier New")
	textAlign("center")
	text("Home", windowWidth / 2, windowHeight / 2 + 10)
	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - 100 & 
			mouseX <= windowWidth / 2 + 100 & 
			mouseY >= windowHeight / 2 - 25 & 
			mouseY <= windowHeight / 2 + 25
		 ){
		setTimeout(Return, 250)	//WEAKLY PREVENTING CONSECUTIVE SELECTIONS.
	}
	fill("grey")
	rect(windowWidth / 2 - 100, windowHeight / 2 - 125, 200, 50, 10)
	fill("green")
	textFont("Courier New")
	textAlign("center")
	text("Continue", windowWidth / 2, windowHeight / 2  - 75 - 25/4 - 10)
	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - 100 & 
			mouseX <= windowWidth / 2 + 100 & 
			mouseY >= windowHeight / 2 - 125 & 
			mouseY <= windowHeight / 2 - 75
		 ){
		setTimeout(StopPause, 250)	//WEAK CONSECUTIVE SELECTION PREVENTION.
	}
	textFont("Trebuchet MS")
}

function FinishWait(){
	ModeSel = 0;
	ShowHelp = true;
}

function RESULT(){
	/*
	We'll surely code the winning screen based on the configurations we gave the game.
	*/
	//FOR NOW, THE ONLY RESULT IS LOSS - THE OTHER IS... WELL. YOU DON'T HAVE THAT MUCH TIME.
	
	textFont("Courier New")
	fill("crimson")
	textAlign("center")
	text("YOU LOST!", windowWidth / 2, windowHeight / 2 - 150)
	fill("yellow")
	textAlign("center")
	text("Score: " + score, windowWidth / 2, windowHeight / 2 - 75)
	fill("grey")
	rect(windowWidth / 2 - 100, windowHeight / 2 - 25, 200, 50)
	textFont("Trebuchet MS")
	fill("cyan")
	textAlign("center")
	text("Main Menu", windowWidth / 2, windowHeight / 2 + 10)
	if (mouseIsPressed & 
			mouseX >= windowWidth / 2 - 100 & 
			mouseX <= windowWidth / 2 + 100 & 
			mouseY >= windowHeight / 2 - 25 & 
			mouseY <= windowHeight / 2 + 25
		 ){
		Paused = false;
		setTimeout(FinishWait, 250)
	}
}

function draw(){
	//START SCREEN
	if (ModeSel == 0){
		Paused = false;
		StartSCR()
	}

	else if (ModeSel == 1 && Paused == false) {
	if (ShowHelp) {
		HelperScreen(1); // show controls for competition
	} else {
		Competition();
	}
}

	else if (ModeSel == 2 && Paused == false) {
	if (ShowHelp) {
		HelperScreen(2);
	} else {
		SinglePlayer();
	}
}

else if (ModeSel == 3 && Paused == false) {
	if (ShowHelp) {
		HelperScreen(3);
	} else {
		Obstacles();
	}
}

else if (ModeSel == 4 && Paused == false) {
	if (ShowHelp) {
		HelperScreen(4);
	} else {
		Miniaturized();
	}
}

else if (ModeSel == 4 && Paused == false) {
	if (ShowHelp) {
		HelperScreen(4);
	} else {
		Miniaturized();
	}
}

	//PAUSED
	else if (Paused == true){
		Pause()
	}
	//GAME ENDS
	else if (ModeSel == -1){
		RESULT()
	}
	//A CATCHER SORT OF THING
	else{
		StartSCR()
	}
}

function keyPressed() {
	if (key === 'q' || key === 'Q') {
		if (!Paused) {
			Paused = true;
		}
	}
}
